/** Instructions to install the objects in HEARTLAND schema**/


(Please execute below file from the HEARTLAND/PART2 folder.)
1. Run the heartland_objects.sql to install objects in HEARTLAND.

Please reach out to appsupport@n2nservices.com for any questions or concerns include the heartland_objects.log file if any script fail.
