--------------------------------------------------------
--  HEARTLAND Objects   
--------------------------------------------------------
set define off
spool heartland_objects.log
set serveroutput off
ALTER SESSION SET PLSQL_OPTIMIZE_LEVEL = 2;
@VIEWS/N_VEW_STUDENT_DELTA.sql
begin
dbms_utility.compile_schema(schema =>  'HEARTLAND',compile_all => true);
end;
/
spool off