--------------------------------------------------------
--  DDL for Table N_SCHEDULER
--------------------------------------------------------

  CREATE TABLE "HEARTLAND"."N_SCHEDULER" 
   (	"PROCESS_STARTTIME" DATE, 
	"SCHEDULER_STARTTIME" DATE, 
	"SCHEDULER_ENDTIME" DATE, 
	"JOB_NAME" VARCHAR2(50 CHAR)
   ) ;
