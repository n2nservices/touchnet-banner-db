--------------------------------------------------------
--  HEARTLAND Objects   
--------------------------------------------------------
set define off
spool heartland_objects.log
set serveroutput off
ALTER SESSION SET PLSQL_OPTIMIZE_LEVEL = 2;
@PACKAGES/N_PKG_REFRESH_MV.sql
begin
dbms_utility.compile_schema(schema =>  'HEARTLAND',compile_all => true);
end;
/
@MATERIALIZED_VIEWS/N_MV_BUSPASS.sql
@MATERIALIZED_VIEWS/N_MV_EMPLOYEE.sql
begin
dbms_utility.compile_schema(schema =>  'HEARTLAND',compile_all => true);
end;
/
@VIEWS/N_VEW_BUSPASS_DELTA.sql
@VIEWS/N_VEW_EMPLOYEE_DELTA.sql
@PACKAGE_BODIES/N_PKG_REFRESH_MV.sql
begin
dbms_utility.compile_schema(schema =>  'HEARTLAND',compile_all => true);
end;
/
spool off